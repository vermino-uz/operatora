import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react-swc";
import {defineConfig} from "vite";

import vitePluginPreviewAnnotations from "./plugins/vite-plugin-preview-annotations";

// https://vite.dev/config/
export default defineConfig({
  optimizeDeps: {
    exclude: ["maplibre-gl"],
    include: ["@heroui/react", "@heroui-pro/react", "@iconify/react"],
  },
  plugins: [vitePluginPreviewAnnotations(), react(), tailwindcss()],
  server: {
    allowedHosts: true,
    host: "0.0.0.0",
    port: 3000,
  },
});
