import {expect, test} from "@playwright/test";

const routes = [
  "/",
  "/orders",
  "/tracker",
  "/analytics",
  "/settings",
  "/help",
] as const;

const homePaths: readonly string[] = [
  "/",
];

for (const route of routes) {
  test(`renders ${route}`, async ({page}) => {
    await page.goto(route);

    await expect(page.locator("#root")).toBeVisible();

    if (homePaths.includes(route)) {
      await expect(page.locator("body")).not.toContainText("Page not found.");
    } else {
      await expect(page.locator("body")).toContainText("Page not found.");
    }
  });
}
