<!-- heroui-design-system-context:managed -->
# Product

## Register

product

## Users

Not specified.

## Product Purpose

Operatora is an AI‑powered sales platform that consolidates Instagram, WhatsApp, Telegram, SMS and other lead sources into a single CRM board. Its OperatoraPhone softphone lets agents handle calls, chats and CRM actions from Windows (macOS, iOS, Android coming soon). The platform offers AI assistants, real‑time analytics dashboards, automated follow‑ups, and drag‑and‑drop pipeline management. Built on six core modules—AI Assistant, CRM & Pipeline, Real‑time Analytics, Automation, Integrations (50+ services), and 24/7 multilingual support—Operatora scales from solo entrepreneurs (free tier) to large enterprises with dedicated SIP/SIM, custom prompts and SLA‑backed hosting. Pricing tiers include Mid‑Business, Large Business with Agentic Mode, and Enterprise, all designed to boost conversion rates and sales productivity.

## Brand Personality

Not specified.

## Anti-References

None specified.

## Accessibility Needs

Maintain clear information hierarchy, keyboard-accessible interactions, readable copy, and sufficient contrast across product-critical flows.

## Product Context

- Name: Operatora
- Website: https://operatora.ai
- Logo: https://media.brand.dev/1292ddad-9dfa-458b-a4f4-2e701430d143.png
- Mark: https://media.brand.dev/1292ddad-9dfa-458b-a4f4-2e701430d143.png
- Hero Fig 1920: https://media.brand.dev/temp-images/5d64738c-f811-462b-aa40-83e218cd4dee.jpg
- Hero Fig 1280: https://media.brand.dev/temp-images/5201187c-53ee-4bc1-9e18-f698e6d79e54.jpg
- Hero Mobile 800: https://media.brand.dev/temp-images/2a327a31-3acd-4b15-be74-60b3d2be6277.webp
- Hero Mobile 800: https://media.brand.dev/temp-images/6e39b106-b515-48ad-a655-452d16b2371b.jpg
- Hero Fig 1920: https://media.brand.dev/temp-images/f60d69e4-9877-4745-82bf-65ac7d476304.webp
- Hero Fig 1280: https://media.brand.dev/temp-images/db6fafba-ef0f-4f62-a431-5dbce83c7656.webp
- Operatora: https://media.brand.dev/temp-images/443d0a3b-6700-44e8-b59d-13a3dc284a39.png
- Operatora Mark: https://media.brand.dev/temp-images/42c33d9b-6409-459e-8034-d3c8ed707e9b.svg
- Av Jahongir: https://media.brand.dev/temp-images/0e452610-a06a-48ab-9a59-94201c551104.svg
- Av Sevinch: https://media.brand.dev/temp-images/54deacaf-c33f-47e9-bc37-f0c2d19fe9c2.svg
- Av Akmal: https://media.brand.dev/temp-images/e68636c1-414b-40d8-9a65-4a5ed52b9d7b.svg
- Av Nilufar: https://media.brand.dev/temp-images/30ddb227-dda0-4341-a582-0f6bd3d16d4c.svg
