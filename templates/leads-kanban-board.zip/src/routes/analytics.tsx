import {AnalyticsPage} from "../views/analytics-page";

export function AnalyticsRoute() {
  return <AnalyticsPage />;
}
