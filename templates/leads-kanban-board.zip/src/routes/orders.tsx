import {OrdersPage} from "../views/orders-page";

export function OrdersRoute() {
  return <OrdersPage />;
}
