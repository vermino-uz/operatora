import {DashboardPage} from "../views/dashboard-page";

export function DashboardRoute() {
  return <DashboardPage />;
}
