import {TrackerPage} from "../views/tracker-page";

export function TrackerRoute() {
  return <TrackerPage />;
}
