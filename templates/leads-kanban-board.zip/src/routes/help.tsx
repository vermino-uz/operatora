import {HelpPage} from "../views/help-page";

export function HelpRoute() {
  return <HelpPage />;
}
