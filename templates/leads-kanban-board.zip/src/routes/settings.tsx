import {SettingsPage} from "../views/settings-page";

export function SettingsRoute() {
  return <SettingsPage />;
}
