import {StrictMode} from "react";
import {createRoot} from "react-dom/client";
import {RouterProvider} from "react-router";

import {applyBrandDocumentMetadata} from "./brand";
import {router} from "./router";

import "./index.css";

// Tab title + favicon follow src/brand/metadata.json (name, tagline, assets).
applyBrandDocumentMetadata();

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <RouterProvider router={router} />
  </StrictMode>,
);
