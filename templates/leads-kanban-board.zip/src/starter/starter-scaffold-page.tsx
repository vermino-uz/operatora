export function StarterScaffoldPage() {
  return (
    <section className="flex min-h-[60dvh] items-center justify-center p-6 text-center">
      <p
        aria-live="polite"
        className="loading-shimmer text-sm font-normal opacity-50"
        role="status"
      >
        Making something great...
      </p>
    </section>
  );
}
