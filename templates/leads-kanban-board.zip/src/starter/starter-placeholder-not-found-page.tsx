export function StarterPlaceholderNotFoundPage() {
  return (
    <section className="flex min-h-[60dvh] items-center justify-center p-6 text-center">
      <p className="text-muted text-sm">Page not found.</p>
    </section>
  );
}
