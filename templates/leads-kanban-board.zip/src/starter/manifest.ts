export const starterManifest = {
  "description": "SaaS/admin dashboard scaffold with app shell, KPIs, charts, tables, settings, and help references.",
  "guidance": [
    "Read this manifest before substantial UI edits.",
    "The visible routes mount editable src/views/* files that initially render neutral scaffold pages inside the starter shell.",
    "Only the home route view renders StarterScaffoldPage with \"Making something great...\"; other route views render StarterPlaceholderNotFoundPage until generated.",
    "Edit the relevant src/views/* file, route file, or both so the live route renders the user's requested screen.",
    "For first-turn generation, replace every routeViews file that imports StarterScaffoldPage with real prompt-specific UI before finalizing.",
    "Do not leave any visible route rendering StarterScaffoldPage or showing \"Making something great...\" after generation completes.",
    "Use components, widgets, data, and reference views as editable reference material.",
    "Treat src/starter/reference/views/* as reference compositions, not final content to leave unchanged.",
    "Replace demo copy, demo data, and neutral scaffold pages with the user's requested app."
  ],
  "id": "dashboard",
  "label": "Dashboard",
  "reusableFiles": {
    "components": [
      "src/components/app-shell.tsx",
      "src/components/dashboard-navbar.tsx",
      "src/components/dashboard-sidebar.tsx",
      "src/components/icon-button.tsx"
    ],
    "data": [
      "src/data/analytics.ts",
      "src/data/employees.ts",
      "src/data/orders.ts",
      "src/data/sales.ts",
      "src/data/tracker.ts",
      "src/data/traffic.ts"
    ],
    "navigation": [
      "src/nav-items.ts"
    ],
    "referenceViews": [
      "src/starter/reference/views/analytics-page.tsx",
      "src/starter/reference/views/dashboard-page.tsx",
      "src/starter/reference/views/help-page.tsx",
      "src/starter/reference/views/orders-page.tsx",
      "src/starter/reference/views/settings-page.tsx",
      "src/starter/reference/views/tracker-page.tsx"
    ],
    "routeViews": [
      "src/views/analytics-page.tsx",
      "src/views/dashboard-page.tsx",
      "src/views/help-page.tsx",
      "src/views/orders-page.tsx",
      "src/views/settings-page.tsx",
      "src/views/tracker-page.tsx"
    ],
    "widgets": [
      "src/widgets/analytics-kpi-row.tsx",
      "src/widgets/dashboard-toolbar.tsx",
      "src/widgets/device-breakdown-card.tsx",
      "src/widgets/employees-table-row-actions.tsx",
      "src/widgets/employees-table.tsx",
      "src/widgets/kpi-row.tsx",
      "src/widgets/orders-row-actions.tsx",
      "src/widgets/sales-performance-card.tsx",
      "src/widgets/sessions-over-time-card.tsx",
      "src/widgets/top-channels-card.tsx",
      "src/widgets/top-pages-card.tsx",
      "src/widgets/traffic-source-card.tsx"
    ]
  },
  "routePaths": [
    "/",
    "/orders",
    "/tracker",
    "/analytics",
    "/settings",
    "/help"
  ],
  "shellFiles": [
    "src/App.tsx",
    "src/components/app-shell.tsx",
    "src/components/dashboard-navbar.tsx",
    "src/components/dashboard-sidebar.tsx"
  ]
} as const;
