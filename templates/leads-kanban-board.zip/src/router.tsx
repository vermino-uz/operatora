import {createBrowserRouter} from "react-router";

import App from "./App";
import {PreviewErrorBoundary} from "./components/preview-error-boundary";
import {AnalyticsRoute} from "./routes/analytics";
import {DashboardRoute} from "./routes";
import {HelpRoute} from "./routes/help";
import {NotFoundRoute} from "./routes/not-found";
import {OrdersRoute} from "./routes/orders";
import {SettingsRoute} from "./routes/settings";
import {TrackerRoute} from "./routes/tracker";

export const router = createBrowserRouter([
  {
    Component: App,
    ErrorBoundary: PreviewErrorBoundary,
    children: [
      {Component: DashboardRoute, index: true},
      {Component: OrdersRoute, path: "orders"},
      {Component: TrackerRoute, path: "tracker"},
      {Component: AnalyticsRoute, path: "analytics"},
      {Component: SettingsRoute, path: "settings"},
      {Component: HelpRoute, path: "help"},
      {Component: NotFoundRoute, path: "*"},
    ],
    path: "/",
  },
]);
