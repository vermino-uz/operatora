import type {ComponentType} from "react";

import {ArrowRightFromSquare, ChartColumn, CircleQuestion, Gear, Persons, Target} from "./icons/gravity";

export type NavItem = {
  readonly href: string;
  readonly label: string;
  readonly icon: ComponentType<{className?: string}>;
  readonly badge?: string;
};

export const NAV_ITEMS: readonly NavItem[] = [
  {href: "/", icon: Target, label: "Leads"},
  {href: "/orders", icon: Persons, label: "Contacts"},
  {href: "/analytics", icon: ChartColumn, label: "Analytics"},
  {href: "/settings", icon: Gear, label: "Settings"},
] as const;

export const FOOTER_ITEMS: readonly NavItem[] = [
  {href: "/help", icon: CircleQuestion, label: "Help & Information"},
  {href: "/logout", icon: ArrowRightFromSquare, label: "Log out"},
] as const;
