import {RouterProvider} from "react-aria-components";
import {Outlet, useHref, useNavigate} from "react-router";

import {AppShell} from "./components/app-shell";

export default function App() {
  const navigate = useNavigate();

  return (
    <RouterProvider navigate={navigate} useHref={useHref}>
      <AppShell>
        <Outlet />
      </AppShell>
    </RouterProvider>
  );
}
