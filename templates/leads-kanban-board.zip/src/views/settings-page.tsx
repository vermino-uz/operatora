import {StarterPlaceholderNotFoundPage} from "../starter/starter-placeholder-not-found-page";

// Route placeholder until this screen is generated. Replace with user-specific content.
export function SettingsPage() {
  return <StarterPlaceholderNotFoundPage />;
}
