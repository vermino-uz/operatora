"use client";

import type {UseKanbanReturn} from "@heroui-pro/react/kanban";
import type {Lead, LeadStage} from "../data/leads";

import {useState} from "react";
import {Ellipsis, Funnel, Magnifier, Plus} from "@gravity-ui/icons";
import {Avatar, Button, Chip, Drawer, Dropdown, Label, Pagination, Separator, Tabs} from "@heroui/react";
import {Kanban, useKanban, useKanbanColumn} from "@heroui-pro/react/kanban";

import {Iconify} from "../icons/iconify";
import {INITIAL_LEADS, LEAD_STAGES, STAGE_CONFIG} from "../data/leads";

const PRIORITY_CONFIG = {
  high: {color: "danger" as const, label: "High"},
  medium: {color: "warning" as const, label: "Medium"},
  low: {color: "default" as const, label: "Low"},
};

const PAGE_SIZES = [3, 10, 20, 50] as const;
type PageSize = (typeof PAGE_SIZES)[number];

function formatCurrency(value: number) {
  if (value >= 1000) return `$${(value / 1000).toFixed(0)}k`;
  return `$${value}`;
}

function SectionTitle({children}: {children: React.ReactNode}) {
  return (
    <p className="text-muted mb-2 text-xs font-semibold uppercase tracking-wider">{children}</p>
  );
}

function FieldRow({
  label,
  children,
  muted,
}: {
  label: string;
  children: React.ReactNode;
  muted?: boolean;
}) {
  return (
    <div className="grid grid-cols-[130px_1fr] items-center gap-3 py-2">
      <span className="text-muted text-sm">{label}</span>
      <div className={`text-sm ${muted ? "text-muted" : "text-foreground"}`}>{children}</div>
    </div>
  );
}

function LeadDetailDrawer({lead, onClose}: {lead: Lead | null; onClose: () => void}) {
  const [copied, setCopied] = useState(false);

  if (!lead) return null;
  const stageConfig = STAGE_CONFIG[lead.stage];
  const isLost = lead.stage === "Lost";

  function copyId(id: string) {
    navigator.clipboard?.writeText(id);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1500);
  }

  return (
    <Drawer>
      <Drawer.Backdrop
        variant="blur"
        isDismissable
        isOpen={!!lead}
        onOpenChange={(open) => {
          if (!open) onClose();
        }}
      >
        <Drawer.Content placement="right" className="w-full max-w-md">
          <Drawer.Dialog aria-label={`${lead.name} details`}>
            <Drawer.Header className="border-b border-border pb-3">
              <div className="flex items-center gap-3">
                <Drawer.CloseTrigger className="shrink-0" />
                <Drawer.Heading
                  className={`truncate text-lg font-semibold ${isLost ? "line-through opacity-60" : ""}`}
                >
                  {lead.name}
                </Drawer.Heading>
                <Chip color={stageConfig.chipColor} size="sm" variant="soft" className="shrink-0">
                  {lead.stage}
                </Chip>
                <div className="ml-auto flex shrink-0 items-center gap-2">
                  <Button size="sm" variant="secondary">
                    <Iconify icon="pencil" className="size-4" />
                    Edit
                  </Button>
                  <Dropdown>
                    <Button isIconOnly aria-label="More actions" size="sm" variant="secondary">
                      <Ellipsis className="size-4" />
                    </Button>
                    <Dropdown.Popover placement="bottom end">
                      <Dropdown.Menu aria-label="Lead actions">
                        <Dropdown.Item id="reassign" textValue="Reassign">
                          <Label>Reassign</Label>
                        </Dropdown.Item>
                        <Dropdown.Item id="duplicate" textValue="Duplicate">
                          <Label>Duplicate</Label>
                        </Dropdown.Item>
                        <Dropdown.Item id="delete" textValue="Delete" variant="danger">
                          <Label>Delete</Label>
                        </Dropdown.Item>
                      </Dropdown.Menu>
                    </Dropdown.Popover>
                  </Dropdown>
                </div>
              </div>
            </Drawer.Header>

            <Drawer.Body className="p-0">
              <Tabs variant="secondary" defaultSelectedKey="info" className="w-full">
                <Tabs.ListContainer className="border-b border-border px-5">
                  <Tabs.List aria-label="Lead sections">
                    <Tabs.Tab id="info">
                      Info
                      <Tabs.Indicator />
                    </Tabs.Tab>
                    <Tabs.Tab id="notes">
                      {`Notes (${lead.notes})`}
                      <Tabs.Indicator />
                    </Tabs.Tab>
                    <Tabs.Tab id="conversations">
                      {`Chats (${lead.conversations})`}
                      <Tabs.Indicator />
                    </Tabs.Tab>
                    <Tabs.Tab id="sms">
                      SMS
                      <Tabs.Indicator />
                    </Tabs.Tab>
                    <Tabs.Tab id="tasks">
                      Tasks
                      <Tabs.Indicator />
                    </Tabs.Tab>
                    <Tabs.Tab id="stats">
                      Stats
                      <Tabs.Indicator />
                    </Tabs.Tab>
                  </Tabs.List>
                </Tabs.ListContainer>

                <Tabs.Panel id="info" className="px-5 pb-6 pt-4">
                  <section>
                    <SectionTitle>Tags</SectionTitle>
                    <div className="flex flex-wrap items-center gap-2">
                      {lead.tags.map((tag) => (
                        <Chip key={tag} size="sm" variant="secondary">
                          {tag}
                        </Chip>
                      ))}
                      <Button size="sm" variant="ghost" className="text-muted border border-dashed border-border">
                        <Plus className="size-3.5" />
                        Add tag
                      </Button>
                    </div>
                  </section>

                  <Separator className="my-4" />

                  <section>
                    <SectionTitle>Details</SectionTitle>
                    <FieldRow label="Lead ID">
                      <div className="flex items-center gap-2">
                        <span className="text-muted font-mono text-xs">{lead.id}</span>
                        <Button
                          isIconOnly
                          aria-label="Copy lead ID"
                          size="sm"
                          variant="ghost"
                          onPress={() => copyId(lead.id)}
                        >
                          <Iconify
                            icon={copied ? "circle-check" : "copy"}
                            className={`size-4 ${copied ? "text-success" : ""}`}
                          />
                        </Button>
                      </div>
                    </FieldRow>
                  </section>

                  <Separator className="my-4" />

                  <section>
                    <SectionTitle>Contact</SectionTitle>
                    <FieldRow label="First name">{lead.firstName}</FieldRow>
                    <FieldRow label="Last name">{lead.lastName}</FieldRow>
                    <FieldRow label="Company">{lead.company}</FieldRow>
                    <FieldRow label="Phone">
                      <div className="flex items-center gap-2">
                        <Iconify icon="handset" className="text-accent size-4" />
                        <span className="font-medium">{lead.phone}</span>
                      </div>
                    </FieldRow>
                    <FieldRow label="Email">
                      <a href={`mailto:${lead.email}`} className="text-accent hover:underline">
                        {lead.email}
                      </a>
                    </FieldRow>
                    <FieldRow label="Other numbers">
                      <Button size="sm" variant="ghost" className="text-muted border border-dashed border-border">
                        <Plus className="size-3.5" />
                        Add number
                      </Button>
                    </FieldRow>
                    <FieldRow label="Created">{lead.createdAt}</FieldRow>
                  </section>

                  <Separator className="my-4" />

                  <section>
                    <SectionTitle>Pipeline</SectionTitle>
                    <FieldRow label="Board">{lead.board}</FieldRow>
                    <FieldRow label="Stage">
                      <span className="flex items-center gap-2">
                        <span className={`size-2 rounded-full ${stageConfig.indicatorClass}`} />
                        {lead.stage}
                      </span>
                    </FieldRow>
                    <FieldRow label="Assigned">
                      <span className="flex items-center gap-2">
                        <Avatar className="size-5" color={lead.owner.color} size="sm" variant="soft">
                          <Avatar.Fallback className="text-xs font-semibold">
                            {lead.owner.initials}
                          </Avatar.Fallback>
                        </Avatar>
                        {lead.owner.name}
                      </span>
                    </FieldRow>
                    <FieldRow label="Deadline">
                      <span className="flex flex-wrap items-center gap-2">
                        <Iconify icon="calendar" className="text-muted size-4" />
                        {lead.deadline}
                        {lead.isOverdue && (
                          <Chip color="danger" size="sm" variant="soft">
                            Overdue
                          </Chip>
                        )}
                      </span>
                    </FieldRow>
                    <FieldRow label="Deal value">
                      <span className="font-semibold">{formatCurrency(lead.value)}</span>
                    </FieldRow>
                  </section>

                  <Separator className="my-4" />

                  <section>
                    <SectionTitle>Custom fields</SectionTitle>
                    {lead.fields.map((field) => (
                      <FieldRow key={field.label} label={field.label} muted={!field.value}>
                        {field.value ?? "Not set"}
                      </FieldRow>
                    ))}
                  </section>
                </Tabs.Panel>

                <Tabs.Panel id="notes" className="px-5 pb-6 pt-4">
                  <TabEmpty
                    icon="comments"
                    title={lead.notes ? `${lead.notes} notes` : "No notes yet"}
                    hint="Log calls, meetings and context for this lead."
                    action="Add note"
                  />
                </Tabs.Panel>
                <Tabs.Panel id="conversations" className="px-5 pb-6 pt-4">
                  <TabEmpty
                    icon="comment"
                    title={lead.conversations ? `${lead.conversations} conversations` : "No conversations"}
                    hint="Messages from connected channels appear here."
                    action="Start chat"
                  />
                </Tabs.Panel>
                <Tabs.Panel id="sms" className="px-5 pb-6 pt-4">
                  <TabEmpty
                    icon="envelope"
                    title="No SMS sent"
                    hint="Send a text message to this lead."
                    action="Send SMS"
                  />
                </Tabs.Panel>
                <Tabs.Panel id="tasks" className="px-5 pb-6 pt-4">
                  <TabEmpty
                    icon="circle-check"
                    title="No tasks"
                    hint="Create a follow-up task to stay on track."
                    action="Add task"
                  />
                </Tabs.Panel>
                <Tabs.Panel id="stats" className="px-5 pb-6 pt-4">
                  <TabEmpty
                    icon="chart-column"
                    title="No activity yet"
                    hint="Engagement stats build up as you work this lead."
                  />
                </Tabs.Panel>
              </Tabs>
            </Drawer.Body>
          </Drawer.Dialog>
        </Drawer.Content>
      </Drawer.Backdrop>
    </Drawer>
  );
}

function TabEmpty({
  icon,
  title,
  hint,
  action,
}: {
  icon: string;
  title: string;
  hint: string;
  action?: string;
}) {
  return (
    <div className="flex flex-col items-center gap-3 py-12 text-center">
      <span className="bg-surface-secondary text-muted flex size-12 items-center justify-center rounded-full">
        <Iconify icon={icon} className="size-6" />
      </span>
      <div className="flex flex-col gap-1">
        <p className="text-foreground text-sm font-medium">{title}</p>
        <p className="text-muted text-sm">{hint}</p>
      </div>
      {action && (
        <Button size="sm" variant="secondary">
          <Plus className="size-4" />
          {action}
        </Button>
      )}
    </div>
  );
}

function LeadCard({lead, onOpen}: {lead: Lead; onOpen: (lead: Lead) => void}) {
  const isDone = lead.stage === "Won";
  const isLost = lead.stage === "Lost";
  const priority = PRIORITY_CONFIG[lead.priority];

  return (
    <>
      <div className="flex items-start justify-between gap-2">
        <span
          className="text-foreground text-sm font-semibold leading-snug"
          style={isLost ? {textDecoration: "line-through", opacity: 0.5} : undefined}
        >
          {lead.name}
        </span>
        <div onClick={(e) => e.stopPropagation()}>
          <Dropdown>
            <Button
              isIconOnly
              aria-label="Lead actions"
              className="-mt-0.5 shrink-0"
              size="sm"
              variant="ghost"
            >
              <Ellipsis className="size-4" />
            </Button>
            <Dropdown.Popover placement="bottom end">
              <Dropdown.Menu aria-label="Lead actions">
                <Dropdown.Item id="view" textValue="View details" onAction={() => onOpen(lead)}>
                  <Label>View details</Label>
                </Dropdown.Item>
                <Dropdown.Item id="edit" textValue="Edit lead">
                  <Label>Edit lead</Label>
                </Dropdown.Item>
                <Dropdown.Item id="assign" textValue="Reassign">
                  <Label>Reassign</Label>
                </Dropdown.Item>
                <Dropdown.Item id="delete" textValue="Delete" variant="danger">
                  <Label>Delete</Label>
                </Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown.Popover>
          </Dropdown>
        </div>
      </div>

      <span className="text-muted flex items-center gap-1 text-xs">
        <Iconify icon="briefcase" className="size-3 shrink-0" />
        {lead.company}
      </span>

      <div className="flex flex-wrap items-center gap-1.5">
        <Chip color={priority.color} size="sm" variant="soft">
          {priority.label}
        </Chip>
        {lead.tags.slice(0, 1).map((tag) => (
          <Chip key={tag} size="sm" variant="secondary">
            {tag}
          </Chip>
        ))}
      </div>

      <div className="mt-0.5 flex items-center justify-between">
        <span
          className={`text-sm font-semibold ${
            isDone ? "text-success" : isLost ? "text-muted line-through" : "text-foreground"
          }`}
        >
          {formatCurrency(lead.value)}
        </span>
        <div className="flex items-center gap-1.5">
          <span className="text-muted text-xs">{lead.lastContact}</span>
          <Avatar className="size-6" color={lead.owner.color} size="sm" variant="soft">
            <Avatar.Fallback className="text-xs font-semibold">
              {lead.owner.initials}
            </Avatar.Fallback>
          </Avatar>
        </div>
      </div>
    </>
  );
}

function LeadsColumn({
  column,
  kanban,
  onOpenLead,
}: {
  column: LeadStage;
  kanban: UseKanbanReturn<Lead>;
  onOpenLead: (lead: Lead) => void;
}) {
  const {dragAndDropHooks, items} = useKanbanColumn(kanban, column);
  const config = STAGE_CONFIG[column];
  const stageValue = items.reduce((sum, item) => sum + item.value, 0);

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState<PageSize>(3);
  const totalPages = Math.max(1, Math.ceil(items.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const pageItems = items.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  function handlePageSizeChange(size: PageSize) {
    setPageSize(size);
    setPage(1);
  }

  return (
    <Kanban.Column className="flex flex-col">
      <Kanban.ColumnHeader>
        <Kanban.ColumnIndicator className={config.indicatorClass} />
        <Kanban.ColumnTitle>{column}</Kanban.ColumnTitle>
        <Kanban.ColumnCount>{items.length}</Kanban.ColumnCount>
        <span className="text-muted ml-auto mr-1 text-xs font-medium tabular-nums">
          {formatCurrency(stageValue)}
        </span>
        <Kanban.ColumnActions>
          <Button isIconOnly aria-label="Add lead" size="sm" variant="ghost">
            <Plus className="size-4" />
          </Button>
          <Button isIconOnly aria-label="More options" size="sm" variant="ghost">
            <Ellipsis className="size-4" />
          </Button>
        </Kanban.ColumnActions>
      </Kanban.ColumnHeader>
      <Kanban.ColumnBody className="flex-1 overflow-hidden">
        <Kanban.ScrollShadow className="h-full">
          <Kanban.CardList
            aria-label={column}
            dragAndDropHooks={dragAndDropHooks}
            items={pageItems}
            renderEmptyState={() => (
              <div className="text-muted flex flex-col items-center gap-2 py-8 text-center text-sm">
                <Iconify icon="person" className="size-6 opacity-40" />
                <span>No leads</span>
              </div>
            )}
          >
            {(lead) => (
              <Kanban.Card
                textValue={lead.name}
                onPress={() => onOpenLead(lead)}
              >
                <LeadCard lead={lead} onOpen={onOpenLead} />
              </Kanban.Card>
            )}
          </Kanban.CardList>
        </Kanban.ScrollShadow>
      </Kanban.ColumnBody>
      <div className="border-t border-border bg-surface flex items-center gap-1 px-2 py-2">
        <Dropdown>
          <Button
            aria-label="Per page"
            size="sm"
            variant="ghost"
            className="text-xs px-2 shrink-0"
          >
            {pageSize} / page
          </Button>
          <Dropdown.Popover placement="top start">
            <Dropdown.Menu
              aria-label="Leads per page"
              selectionMode="single"
              selectedKeys={new Set([String(pageSize)])}
              onSelectionChange={(keys) => {
                const val = Number([...keys][0]) as PageSize;
                if (val) handlePageSizeChange(val);
              }}
            >
              {PAGE_SIZES.map((s) => (
                <Dropdown.Item key={s} id={String(s)} textValue={`${s} per page`}>
                  <Label>{s} per page</Label>
                  <Dropdown.ItemIndicator />
                </Dropdown.Item>
              ))}
            </Dropdown.Menu>
          </Dropdown.Popover>
        </Dropdown>
        {totalPages > 1 && (
          <Pagination size="sm" className="flex-1 justify-end">
            <Pagination.Content>
              <Pagination.Item>
                <Pagination.Previous
                  isDisabled={currentPage === 1}
                  onPress={() => setPage((p) => Math.max(1, p - 1))}
                >
                  <Pagination.PreviousIcon />
                </Pagination.Previous>
              </Pagination.Item>
              {Array.from({length: totalPages}, (_, i) => i + 1).map((p) => (
                <Pagination.Item key={p}>
                  <Pagination.Link isActive={p === currentPage} onPress={() => setPage(p)}>
                    {p}
                  </Pagination.Link>
                </Pagination.Item>
              ))}
              <Pagination.Item>
                <Pagination.Next
                  isDisabled={currentPage === totalPages}
                  onPress={() => setPage((p) => Math.min(totalPages, p + 1))}
                >
                  <Pagination.NextIcon />
                </Pagination.Next>
              </Pagination.Item>
            </Pagination.Content>
          </Pagination>
        )}
      </div>
    </Kanban.Column>
  );
}

export function DashboardPage() {
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);

  const kanban = useKanban<Lead>({
    getColumn: (item) => item.stage,
    initialItems: INITIAL_LEADS,
    setColumn: (item, column) => ({...item, stage: column as LeadStage}),
  });

  const wonValue = INITIAL_LEADS.filter((l) => l.stage === "Won").reduce(
    (s, l) => s + l.value,
    0,
  );
  const pipelineValue = INITIAL_LEADS.filter((l) => !["Won", "Lost"].includes(l.stage)).reduce(
    (s, l) => s + l.value,
    0,
  );
  const totalLeads = INITIAL_LEADS.length;

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between border-b border-border px-6 py-4">
        <div className="flex flex-col gap-0.5">
          <h1 className="text-foreground text-lg font-semibold">Leads Pipeline</h1>
          <p className="text-muted text-sm">
            {totalLeads} leads &middot; Pipeline{" "}
            <span className="text-foreground font-medium">
              ${(pipelineValue / 1000).toFixed(0)}k
            </span>{" "}
            &middot; Closed{" "}
            <span className="text-success font-medium">${(wonValue / 1000).toFixed(0)}k</span>
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button size="sm" variant="secondary">
            <Funnel className="size-4" />
            Filter
          </Button>
          <Button size="sm" variant="secondary">
            <Magnifier className="size-4" />
            Search
          </Button>
          <Button size="sm" variant="primary">
            <Plus className="size-4" />
            Add Lead
          </Button>
        </div>
      </div>

      <div className="flex min-h-0 flex-1 overflow-auto p-6">
        <Kanban className="h-full">
          {LEAD_STAGES.map((stage) => (
            <LeadsColumn
              key={stage}
              column={stage}
              kanban={kanban}
              onOpenLead={setSelectedLead}
            />
          ))}
        </Kanban>
      </div>

      <LeadDetailDrawer lead={selectedLead} onClose={() => setSelectedLead(null)} />
    </div>
  );
}
