import type {IconifyProps} from "./iconify";

import {Iconify} from "./iconify";

type GravityIconProps = Omit<IconifyProps, "icon" | "isGravityIcon">;

function createGravityIcon(icon: string) {
  return function GravityIcon(props: GravityIconProps) {
    return <Iconify icon={icon} {...props} />;
  };
}

export const Archive = createGravityIcon("archive");
export const ArrowDownToLine = createGravityIcon("arrow-down-to-line");
export const ArrowLeft = createGravityIcon("arrow-left");
export const ArrowRight = createGravityIcon("arrow-right");
export const ArrowRightFromSquare = createGravityIcon("arrow-right-from-square");
export const ArrowRightToSquare = createGravityIcon("arrow-right-to-square");
export const ArrowShapeTurnUpLeft = createGravityIcon("arrow-shape-turn-up-left");
export const ArrowUpRightFromSquare = createGravityIcon("arrow-up-right-from-square");
export const ArrowsRotateLeft = createGravityIcon("arrows-rotate-left");
export const BarsDescendingAlignCenter = createGravityIcon("bars-descending-align-center");
export const Bell = createGravityIcon("bell");
export const Book = createGravityIcon("book");
export const Calendar = createGravityIcon("calendar");
export const CaretDown = createGravityIcon("caret-down");
export const ChartColumn = createGravityIcon("chart-column");
export const ChartPie = createGravityIcon("chart-pie");
export const ChevronDown = createGravityIcon("chevron-down");
export const ChevronLeft = createGravityIcon("chevron-left");
export const CircleCheck = createGravityIcon("circle-check");
export const CircleDashed = createGravityIcon("circle-dashed");
export const CirclePlay = createGravityIcon("circle-play");
export const CircleQuestion = createGravityIcon("circle-question");
export const Comment = createGravityIcon("comment");
export const Compass = createGravityIcon("compass");
export const Copy = createGravityIcon("copy");
export const CopyPicture = createGravityIcon("copy-picture");
export const CreditCard = createGravityIcon("credit-card");
export const EllipsisVertical = createGravityIcon("ellipsis-vertical");
export const Eye = createGravityIcon("eye");
export const FileText = createGravityIcon("file-text");
export const Funnel = createGravityIcon("funnel");
export const Gear = createGravityIcon("gear");
export const Globe = createGravityIcon("globe");
export const House = createGravityIcon("house");
export const LayoutColumns3 = createGravityIcon("layout-columns-3");
export const LifeRing = createGravityIcon("life-ring");
export const ListCheck = createGravityIcon("list-check");
export const Magnifier = createGravityIcon("magnifier");
export const Mug = createGravityIcon("mug");
export const PaperPlane = createGravityIcon("paper-plane");
export const Paperclip = createGravityIcon("paperclip");
export const Pencil = createGravityIcon("pencil");
export const PencilToLine = createGravityIcon("pencil-to-line");
export const Percent = createGravityIcon("percent");
export const PersonPlus = createGravityIcon("person-plus");
export const Plane = createGravityIcon("plane");
export const Plus = createGravityIcon("plus");
export const Receipt = createGravityIcon("receipt");
export const ShoppingBag = createGravityIcon("shopping-bag");
export const Sliders = createGravityIcon("sliders");
export const SquareExclamation = createGravityIcon("square-exclamation");
export const SquarePlus = createGravityIcon("square-plus");
export const Star = createGravityIcon("star");
export const StarFill = createGravityIcon("star-fill");
export const Stopwatch = createGravityIcon("stopwatch");
export const Target = createGravityIcon("target");
export const Ticket = createGravityIcon("ticket");
export const TrashBin = createGravityIcon("trash-bin");
export const Tray = createGravityIcon("tray");
export const Xmark = createGravityIcon("xmark");
export const Persons = createGravityIcon("persons");
