import {Skeleton} from "@heroui/react";
import {notFound} from "next/navigation";
import {Suspense} from "react";

import {EmptyState} from "../../../components/empty-state";
import {FOLDERS, getFolder} from "../../../data/email";

export function generateStaticParams() {
  return FOLDERS.map((folder) => ({folder: folder.id}));
}

export default function Page({params}: {params: Promise<{folder: string}>}) {
  return (
    <Suspense fallback={<EmptyStateFallback />}>
      <FolderPage params={params} />
    </Suspense>
  );
}

async function FolderPage({params}: {params: Promise<{folder: string}>}) {
  const {folder: folderId} = await params;
  const folder = getFolder(folderId);

  if (!folder) notFound();

  return <EmptyState folder={folder} />;
}

function EmptyStateFallback() {
  return (
    <div
      aria-busy="true"
      className="flex h-full min-h-0 flex-col items-center justify-center gap-3 px-6 py-16"
    >
      <span className="sr-only">Loading folder</span>
      <Skeleton className="size-12 rounded-2xl" />
      <Skeleton className="h-5 w-28 rounded-md" />
      <Skeleton className="h-4 w-full max-w-[320px] rounded-md" />
    </div>
  );
}
