import {Skeleton} from "@heroui/react";
import {notFound} from "next/navigation";
import {Suspense} from "react";

import {EmailDetail} from "../../../../components/email-detail";
import {THREADS, getThread} from "../../../../data/email";

export function generateStaticParams() {
  return THREADS.map((thread) => ({emailId: thread.id, folder: thread.folderId}));
}

export default function Page({params}: {params: Promise<{emailId: string; folder: string}>}) {
  return (
    <Suspense fallback={<EmailDetailFallback />}>
      <EmailPage params={params} />
    </Suspense>
  );
}

async function EmailPage({params}: {params: Promise<{emailId: string; folder: string}>}) {
  const {emailId, folder} = await params;
  const thread = getThread(emailId);

  if (!thread) notFound();

  return <EmailDetail backHref={`/${folder}`} thread={thread} />;
}

function EmailDetailFallback() {
  return (
    <div
      aria-busy="true"
      className="flex h-full min-h-0 min-w-0 flex-col gap-6 overflow-hidden p-4 lg:py-8 lg:pl-6 lg:pr-8"
    >
      <span className="sr-only">Loading email</span>
      <div className="flex items-center justify-between">
        <Skeleton className="h-8 w-40 rounded-lg" />
        <Skeleton className="h-8 w-24 rounded-lg" />
      </div>
      <Skeleton className="h-5 w-3/5 rounded-md" />
      <div className="flex items-center gap-3">
        <Skeleton className="size-10 rounded-full" />
        <div className="flex flex-1 flex-col gap-2">
          <Skeleton className="h-4 w-40 rounded-md" />
          <Skeleton className="h-3 w-24 rounded-md" />
        </div>
      </div>
      <div className="flex flex-col gap-3">
        <Skeleton className="h-4 w-full rounded-md" />
        <Skeleton className="h-4 w-11/12 rounded-md" />
        <Skeleton className="h-4 w-4/5 rounded-md" />
      </div>
    </div>
  );
}
