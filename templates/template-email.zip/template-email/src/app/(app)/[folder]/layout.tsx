import type {ReactNode} from "react";

import {Skeleton} from "@heroui/react";
import {notFound} from "next/navigation";
import {Suspense} from "react";

import {FolderLayout} from "../../../components/folder-layout";
import {getFolder, getThreadsForFolder} from "../../../data/email";

export default function Layout({
  children,
  params,
}: {
  children: ReactNode;
  params: Promise<{folder: string}>;
}) {
  return (
    <Suspense fallback={<FolderRouteFallback />}>
      <FolderRoute params={params}>{children}</FolderRoute>
    </Suspense>
  );
}

async function FolderRoute({
  children,
  params,
}: {
  children: ReactNode;
  params: Promise<{folder: string}>;
}) {
  const {folder: folderId} = await params;
  const folder = getFolder(folderId);

  if (!folder) notFound();

  const threads = getThreadsForFolder(folderId);

  return (
    <FolderLayout basePath="" folderId={folder.id} threads={threads}>
      {children}
    </FolderLayout>
  );
}

function FolderRouteFallback() {
  return (
    <div
      aria-busy="true"
      className="flex h-svh flex-col overflow-hidden lg:grid lg:grid-cols-[minmax(320px,360px)_1fr]"
    >
      <span className="sr-only">Loading folder</span>
      <div className="flex min-h-0 flex-1 flex-col gap-3 px-2 pb-2 pt-4">
        <Skeleton className="h-10 w-full rounded-xl" />
        <Skeleton className="h-24 w-full rounded-xl" />
        <Skeleton className="h-24 w-full rounded-xl" />
        <Skeleton className="h-24 w-full rounded-xl" />
      </div>
      <div className="hidden min-h-0 items-center justify-center lg:flex">
        <Skeleton className="h-24 w-64 rounded-2xl" />
      </div>
    </div>
  );
}
