"use client";

import type {EmailMessage, EmailThread} from "../data/email";

import {
  Archive,
  ArrowLeft,
  ArrowRight,
  ArrowShapeTurnUpLeft,
  CaretDown,
  ChevronLeft,
  EllipsisVertical,
  Star,
  StarFill,
  TrashBin,
  Xmark,
} from "@gravity-ui/icons";
import {Avatar, Button, CloseButton, ScrollShadow, Separator} from "@heroui/react";
import Link from "next/link";

export interface EmailDetailProps {
  thread: EmailThread;
  /**
   * URL to navigate back to the list column. When provided, a mobile back
   * button appears in the toolbar and the close button collapses to desktop
   * only. Storybook previews omit this prop to keep the toolbar inert.
   */
  backHref?: string;
  onArchive?: (threadId: string) => void;
  onClose?: () => void;
  onNext?: () => void;
  onPrevious?: () => void;
  onReply?: (threadId: string) => void;
  onToggleStar?: (threadId: string) => void;
  onTrash?: (threadId: string) => void;
  position?: {current: number; total: number};
}

function getInitials(name: string) {
  return name
    .split(" ")
    .map((part) => part[0])
    .join("");
}

export function EmailDetail({
  backHref,
  onArchive,
  onClose,
  onNext,
  onPrevious,
  onReply,
  onToggleStar,
  onTrash,
  position,
  thread,
}: EmailDetailProps) {
  return (
    <div className="flex h-full min-h-0 min-w-0 flex-col overflow-clip lg:py-4 lg:pl-0.5 lg:pr-4">
      <div className="lg:bg-surface lg:shadow-surface flex max-h-full flex-1 flex-col gap-6 overflow-clip p-4 lg:rounded-2xl">
        <Toolbar
          backHref={backHref}
          isStarred={thread.isStarred}
          messageCount={thread.messages.length}
          position={position}
          onArchive={() => onArchive?.(thread.id)}
          onClose={onClose}
          onNext={onNext}
          onPrevious={onPrevious}
          onToggleStar={() => onToggleStar?.(thread.id)}
          onTrash={() => onTrash?.(thread.id)}
        />

        <ScrollShadow hideScrollBar className="min-h-0 flex-1 overflow-y-auto lg:px-6">
          <div className="flex flex-col gap-8 pb-5">
            <h1 className="text-foreground text-base font-semibold leading-normal">
              {thread.subject}
            </h1>

            {thread.messages.map((message, index) => (
              <div key={message.id} className="flex flex-col gap-6">
                {index > 0 ? <Separator /> : null}
                <ThreadMessage
                  isStarred={thread.isStarred}
                  message={message}
                  onReply={onReply ? () => onReply(thread.id) : undefined}
                  onToggleStar={onToggleStar ? () => onToggleStar(thread.id) : undefined}
                />
              </div>
            ))}
          </div>
        </ScrollShadow>
      </div>
    </div>
  );
}

interface ToolbarProps {
  backHref?: string;
  isStarred: boolean;
  messageCount: number;
  onArchive?: () => void;
  onClose?: () => void;
  onNext?: () => void;
  onPrevious?: () => void;
  onToggleStar?: () => void;
  onTrash?: () => void;
  position?: {current: number; total: number};
}

function Toolbar({
  backHref,
  isStarred,
  messageCount,
  onArchive,
  onClose,
  onNext,
  onPrevious,
  onToggleStar,
  onTrash,
  position,
}: ToolbarProps) {
  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-4">
        {onClose ? (
          <Button
            isIconOnly
            aria-label="Close"
            className="text-muted"
            size="sm"
            variant="ghost"
            onPress={onClose}
          >
            <Xmark className="size-4" />
          </Button>
        ) : backHref ? (
          <>
            <BackButton href={backHref} />
            <CloseLink href={backHref} />
          </>
        ) : (
          <CloseButton />
        )}
        <div className="flex items-center">
          <Button
            isIconOnly
            aria-label="Move to trash"
            className="text-muted hover:text-foreground"
            size="sm"
            variant="ghost"
            onPress={onTrash}
          >
            <TrashBin className="size-4" />
          </Button>
          <Button
            isIconOnly
            aria-label="Archive"
            className="text-muted hover:text-foreground"
            size="sm"
            variant="ghost"
            onPress={onArchive}
          >
            <Archive className="size-4" />
          </Button>
          <Button
            isIconOnly
            aria-label={isStarred ? "Remove star" : "Add star"}
            className="text-muted hover:text-foreground"
            size="sm"
            variant="ghost"
            onPress={onToggleStar}
          >
            {isStarred ? <StarFill className="text-warning size-4" /> : <Star className="size-4" />}
          </Button>
        </div>
      </div>

      <div className="flex items-center gap-4 px-2">
        <span className="text-muted text-xs tabular-nums">
          {position ? `${position.current} of ${position.total}` : `${messageCount} messages`}
        </span>
        <div className="flex items-center">
          <Button
            isIconOnly
            aria-label="Previous"
            className="text-muted hover:text-foreground"
            size="sm"
            variant="ghost"
            onPress={onPrevious}
          >
            <ArrowLeft className="size-4" />
          </Button>
          <Button
            isIconOnly
            aria-label="Next"
            className="text-muted hover:text-foreground"
            size="sm"
            variant="ghost"
            onPress={onNext}
          >
            <ArrowRight className="size-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}

function ThreadMessage({
  isStarred,
  message,
  onReply,
  onToggleStar,
}: {
  isStarred: boolean;
  message: EmailMessage;
  onReply?: () => void;
  onToggleStar?: () => void;
}) {
  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-start justify-between">
        <div className="flex gap-3">
          <Avatar className="size-9 shrink-0">
            <Avatar.Image alt={message.from.name} src={message.from.avatar} />
            <Avatar.Fallback>{getInitials(message.from.name)}</Avatar.Fallback>
          </Avatar>
          <div className="flex flex-col">
            <span className="text-foreground text-sm font-medium leading-tight">
              {message.from.name}
            </span>
            <span className="text-muted text-xs font-medium leading-tight">
              {message.from.email}
            </span>
            <div className="text-muted flex items-center gap-0.5 text-xs font-medium leading-tight">
              <p>to me</p>
              <CaretDown className="text-muted size-3" />
            </div>
          </div>
        </div>

        <div className="flex flex-col items-end gap-2 px-2">
          <span className="text-muted whitespace-nowrap text-xs">{message.receivedAt}</span>
          <div className="flex items-center">
            <Button
              isIconOnly
              aria-label="Reply"
              className="text-muted hover:text-foreground"
              variant="ghost"
              onPress={onReply}
            >
              <ArrowShapeTurnUpLeft className="size-4" />
            </Button>
            <Button
              isIconOnly
              aria-label={isStarred ? "Remove star" : "Add star"}
              className="text-muted hover:text-foreground"
              variant="ghost"
              onPress={onToggleStar}
            >
              {isStarred ? (
                <StarFill className="text-warning size-4" />
              ) : (
                <Star className="size-4" />
              )}
            </Button>
            <Button
              isIconOnly
              aria-label="More"
              className="text-muted hover:text-foreground"
              variant="ghost"
            >
              <EllipsisVertical className="size-4" />
            </Button>
          </div>
        </div>
      </div>

      <div className="text-foreground whitespace-pre-wrap text-sm leading-relaxed">
        {message.body.join("\n\n")}
      </div>
    </div>
  );
}

function BackButton({href}: {href: string}) {
  return (
    <Link
      aria-label="Back to list"
      className="border-border text-muted hover:text-foreground inline-flex size-8 items-center justify-center rounded-full border transition-colors lg:hidden"
      href={href}
    >
      <ChevronLeft className="size-4" />
    </Link>
  );
}

function CloseLink({href}: {href: string}) {
  return (
    <Link
      aria-label="Close"
      className="bg-default text-muted hover:bg-default-hover hidden size-6 shrink-0 items-center justify-center rounded-xl transition-colors lg:inline-flex"
      href={href}
    >
      <Xmark className="size-4" />
    </Link>
  );
}
