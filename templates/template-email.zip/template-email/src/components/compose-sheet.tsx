"use client";

import {Paperclip, TrashBin} from "@gravity-ui/icons";
import {Button, Input, Label, TextArea, TextField} from "@heroui/react";
import {Sheet} from "@heroui-pro/react";

export interface ComposeSheetProps {
  composeError?: string;
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  draft?: EmailComposeValue;
  heading?: string;
  onDiscard?: () => void;
  onDraftChange?: (draft: EmailComposeValue) => void;
  onSave?: () => void;
  /** Return false to keep the composer open after validation fails. */
  onSend?: () => boolean | void;
}

export interface EmailComposeValue {
  body: string;
  id?: string;
  inReplyToThreadId?: string;
  revision?: number;
  subject: string;
  to: string;
}

export function ComposeSheet({
  composeError,
  draft,
  heading = "New message",
  isOpen,
  onDiscard,
  onDraftChange,
  onOpenChange,
  onSave,
  onSend,
}: ComposeSheetProps) {
  const updateDraft =
    (field: keyof Pick<EmailComposeValue, "body" | "subject" | "to">) => (value: string) => {
      if (!onDraftChange) return;

      onDraftChange({body: "", subject: "", to: "", ...draft, [field]: value});
    };

  return (
    <Sheet isOpen={isOpen} placement="right" onOpenChange={onOpenChange}>
      <Sheet.Backdrop>
        <Sheet.Content className="w-full md:w-[520px]">
          <Sheet.Dialog>
            <Sheet.CloseTrigger />
            <Sheet.Header>
              <Sheet.Heading>{heading}</Sheet.Heading>
            </Sheet.Header>
            <Sheet.Body>
              <form className="flex flex-col gap-4">
                {composeError ? (
                  <div
                    className="bg-danger-soft text-danger-soft-foreground rounded-xl px-3 py-2 text-sm"
                    role="alert"
                  >
                    {composeError}
                  </div>
                ) : null}
                <TextField name="to" type="text">
                  <Label>To</Label>
                  <Input
                    placeholder="name@example.com"
                    value={draft?.to}
                    variant="secondary"
                    onChange={(event) => updateDraft("to")(event.currentTarget.value)}
                  />
                </TextField>
                <TextField name="subject" type="text">
                  <Label>Subject</Label>
                  <Input
                    placeholder="What's this about?"
                    value={draft?.subject}
                    variant="secondary"
                    onChange={(event) => updateDraft("subject")(event.currentTarget.value)}
                  />
                </TextField>
                <TextField name="body">
                  <Label>Message</Label>
                  <TextArea
                    className="min-h-[220px]"
                    placeholder="Write something thoughtful..."
                    value={draft?.body}
                    variant="secondary"
                    onChange={(event) => updateDraft("body")(event.currentTarget.value)}
                  />
                </TextField>
              </form>
            </Sheet.Body>
            <Sheet.Footer className="justify-between">
              <div className="flex items-center gap-1">
                <Button isIconOnly aria-label="Attach file" size="sm" variant="ghost">
                  <Paperclip className="size-4" />
                </Button>
                <Button
                  isIconOnly
                  aria-label="Discard draft"
                  size="sm"
                  variant="ghost"
                  onPress={() => {
                    onDiscard?.();
                    onOpenChange(false);
                  }}
                >
                  <TrashBin className="size-4" />
                </Button>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  size="sm"
                  variant="tertiary"
                  onPress={() => {
                    onSave?.();
                    onOpenChange(false);
                  }}
                >
                  Save draft
                </Button>
                <Button
                  size="sm"
                  onPress={() => {
                    const shouldClose = onSend?.();

                    if (shouldClose !== false) onOpenChange(false);
                  }}
                >
                  Send
                </Button>
              </div>
            </Sheet.Footer>
          </Sheet.Dialog>
        </Sheet.Content>
      </Sheet.Backdrop>
    </Sheet>
  );
}
