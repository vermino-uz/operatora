"use client";

import type {EmailFolder, EmailThread} from "../data/email";

import {ScrollShadow, SearchField} from "@heroui/react";
import {AppLayout} from "@heroui-pro/react";

import {EmailListItem} from "./email-list-item";

export interface EmailListProps {
  folder: EmailFolder;
  threads: readonly EmailThread[];
  basePath: string;
  disableNavigation?: boolean;
  currentThreadId?: string;
  query?: string;
  onQueryChange?: (query: string) => void;
  onThreadSelect?: (threadId: string) => void;
  onToggleStar?: (threadId: string) => void;
}

export function EmailList({
  basePath,
  currentThreadId,
  disableNavigation = false,
  folder,
  onQueryChange,
  onThreadSelect,
  onToggleStar,
  query,
  threads,
}: EmailListProps) {
  return (
    <div className="flex h-full min-h-0 flex-col gap-3 overflow-clip px-2 pb-2 pt-4">
      <div className="flex items-center gap-2">
        <AppLayout.MenuToggle className="ml-0" />
        <SearchField
          aria-label={`Search ${folder.label.toLowerCase()}`}
          className="flex-1"
          name="folder-search"
          value={query}
          onChange={onQueryChange}
        >
          <SearchField.Group>
            <SearchField.SearchIcon />
            <SearchField.Input placeholder="Search..." />
            <SearchField.ClearButton />
          </SearchField.Group>
        </SearchField>
      </div>

      <ScrollShadow hideScrollBar className="min-h-0 flex-1 overflow-y-auto">
        {threads.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center gap-2 px-6 py-10 text-center">
            <p className="text-foreground text-sm font-medium">
              {query ? "No matching conversations" : "No conversations here"}
            </p>
            <p className="text-muted max-w-[220px] text-xs">
              {query
                ? "Try a sender, subject, label, or a less specific phrase."
                : `When messages land in ${folder.label.toLowerCase()}, they’ll show up here.`}
            </p>
          </div>
        ) : (
          <ul className="flex flex-col gap-0.5">
            {threads.map((thread) => (
              <EmailListItem
                key={thread.id}
                disableNavigation={disableNavigation}
                href={`${basePath}/${folder.id}/${thread.id}`}
                isActive={thread.id === currentThreadId}
                thread={thread}
                onSelect={onThreadSelect}
                onToggleStar={onToggleStar}
              />
            ))}
          </ul>
        )}
      </ScrollShadow>
    </div>
  );
}
