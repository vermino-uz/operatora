"use client";

import type {EmailComposeValue} from "./compose-sheet";
import type {EmailFolderId, EmailThread} from "../data/email";

import {AppLayout} from "@heroui-pro/react";

import {getFolder} from "../data/email";

import {ComposeSheet} from "./compose-sheet";
import {EmailDetail} from "./email-detail";
import {EmailList} from "./email-list";
import {EmailSidebar} from "./email-sidebar";
import {EmptyState} from "./empty-state";

export type EmailThreadAction = "archive" | "star" | "trash" | "unstar";

/**
 * Fully controlled form of the email template. It keeps the template's
 * route-driven screens reusable while allowing an embedded app (or an agent)
 * to own every mailbox mutation.
 */
export interface EmailWorkspaceProps {
  composeDraft?: EmailComposeValue;
  composeError?: string;
  composeHeading?: string;
  folderId: EmailFolderId;
  isComposeOpen: boolean;
  onComposeOpenChange: (open: boolean) => void;
  onDiscardDraft?: () => void;
  onDraftChange: (draft: EmailComposeValue) => void;
  onFolderChange: (folderId: EmailFolderId) => void;
  onQueryChange: (query: string) => void;
  onReply: (threadId: string) => void;
  onSaveDraft: () => void;
  onSendDraft: () => boolean | void;
  onSidebarOpenChange?: (open: boolean) => void;
  onThreadAction: (threadId: string, action: EmailThreadAction) => void;
  onThreadSelect: (threadId: string | null) => void;
  query: string;
  selectedThread?: EmailThread;
  selectedThreadId: string | null;
  sidebarOpen?: boolean;
  threads: readonly EmailThread[];
  unreadCounts: Readonly<Record<EmailFolderId, number>>;
}

export function EmailWorkspace({
  composeDraft,
  composeError,
  composeHeading,
  folderId,
  isComposeOpen,
  onComposeOpenChange,
  onDiscardDraft,
  onDraftChange,
  onFolderChange,
  onQueryChange,
  onReply,
  onSaveDraft,
  onSendDraft,
  onSidebarOpenChange,
  onThreadAction,
  onThreadSelect,
  query,
  selectedThread,
  selectedThreadId,
  sidebarOpen,
  threads,
  unreadCounts,
}: EmailWorkspaceProps) {
  const folder = getFolder(folderId);

  if (!folder) return null;

  const selectedIndex = selectedThreadId
    ? threads.findIndex((thread) => thread.id === selectedThreadId)
    : -1;
  const hasSelection = Boolean(selectedThread);

  return (
    <AppLayout
      className="h-full min-h-0 overflow-hidden"
      scrollMode="content"
      sidebarCollapsible="offcanvas"
      sidebarOpen={sidebarOpen}
      sidebar={
        <EmailSidebar
          disableNavigation
          basePath=""
          pathname={`/${folderId}`}
          selectedFolderId={folderId}
          unreadCounts={unreadCounts}
          onCompose={() => onComposeOpenChange(true)}
          onFolderChange={onFolderChange}
        />
      }
      onSidebarOpenChange={onSidebarOpenChange}
    >
      <div className="flex h-full min-h-0 flex-col overflow-hidden lg:grid lg:grid-cols-[minmax(320px,360px)_1fr]">
        <div
          className={`min-h-0 overflow-hidden ${
            hasSelection ? "hidden lg:flex lg:flex-col" : "flex flex-1 flex-col"
          }`}
        >
          <EmailList
            disableNavigation
            basePath=""
            currentThreadId={selectedThreadId ?? undefined}
            folder={folder}
            query={query}
            threads={threads}
            onQueryChange={onQueryChange}
            onThreadSelect={onThreadSelect}
            onToggleStar={(threadId) =>
              onThreadAction(
                threadId,
                threads.find((thread) => thread.id === threadId)?.isStarred ? "unstar" : "star",
              )
            }
          />
        </div>
        <div
          className={`min-h-0 overflow-hidden ${
            hasSelection ? "flex flex-1 flex-col" : "hidden lg:flex lg:flex-col"
          }`}
        >
          {selectedThread ? (
            <EmailDetail
              thread={selectedThread}
              position={
                selectedIndex >= 0
                  ? {current: selectedIndex + 1, total: Math.max(threads.length, 1)}
                  : undefined
              }
              onArchive={(threadId) => onThreadAction(threadId, "archive")}
              onClose={() => onThreadSelect(null)}
              onReply={onReply}
              onTrash={(threadId) => onThreadAction(threadId, "trash")}
              onNext={() => {
                const next = threads[selectedIndex + 1];

                if (next) onThreadSelect(next.id);
              }}
              onPrevious={() => {
                const previous = threads[selectedIndex - 1];

                if (previous) onThreadSelect(previous.id);
              }}
              onToggleStar={(threadId) =>
                onThreadAction(threadId, selectedThread.isStarred ? "unstar" : "star")
              }
            />
          ) : (
            <EmptyState folder={folder} />
          )}
        </div>
      </div>

      <ComposeSheet
        composeError={composeError}
        draft={composeDraft}
        heading={composeHeading}
        isOpen={isComposeOpen}
        onDiscard={onDiscardDraft}
        onDraftChange={onDraftChange}
        onOpenChange={onComposeOpenChange}
        onSave={onSaveDraft}
        onSend={onSendDraft}
      />
    </AppLayout>
  );
}
