"use client";

import type {ReactNode} from "react";

import {AppLayout} from "@heroui-pro/react";
import {usePathname, useRouter} from "next/navigation";
import {Suspense, useCallback, useEffect, useState} from "react";

import {DEFAULT_FOLDER_ID} from "../data/email";

import {ComposeSheet} from "./compose-sheet";
import {EmailSidebar} from "./email-sidebar";

interface EmailSidebarWithPathnameProps {
  basePath: string;
  disableNavigation: boolean;
  onCompose?: () => void;
}

function getDefaultPathname(basePath: string) {
  return `${basePath}/${DEFAULT_FOLDER_ID}`;
}

function EmailSidebarWithPathname({
  basePath,
  disableNavigation,
  onCompose,
}: EmailSidebarWithPathnameProps) {
  const pathname = usePathname();

  return (
    <EmailSidebar
      basePath={basePath}
      disableNavigation={disableNavigation}
      pathname={pathname ?? getDefaultPathname(basePath)}
      onCompose={onCompose}
    />
  );
}

export interface EmailShellProps {
  children: ReactNode;
  basePath?: string;
  disableNavigation?: boolean;
}

export function EmailShell({basePath = "", children, disableNavigation = false}: EmailShellProps) {
  const router = useRouter();
  const [isComposeOpen, setIsComposeOpen] = useState(false);
  const defaultPathname = getDefaultPathname(basePath);
  const handleCompose = useCallback(() => setIsComposeOpen(true), []);
  const onCompose = disableNavigation ? undefined : handleCompose;

  const navigate = useCallback(
    (href: string) => {
      if (disableNavigation) return;
      router.push(basePath + href);
    },
    [router, basePath, disableNavigation],
  );

  // Keyboard shortcut: `C` opens compose. Skipped in preview mode and when
  // focus is inside an input/textarea so normal typing still works.
  useEffect(() => {
    if (disableNavigation) return;

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.metaKey || event.ctrlKey || event.altKey || event.shiftKey) return;
      if (event.key !== "c" && event.key !== "C") return;

      const target = event.target as HTMLElement | null;
      const tagName = target?.tagName.toLowerCase();

      if (tagName === "input" || tagName === "textarea" || target?.isContentEditable) return;

      event.preventDefault();
      setIsComposeOpen(true);
    };

    window.addEventListener("keydown", handleKeyDown);

    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [disableNavigation]);

  return (
    <AppLayout
      navigate={navigate}
      sidebarCollapsible="offcanvas"
      sidebar={
        <Suspense
          fallback={
            <EmailSidebar
              basePath={basePath}
              disableNavigation={disableNavigation}
              pathname={defaultPathname}
              onCompose={onCompose}
            />
          }
        >
          <EmailSidebarWithPathname
            basePath={basePath}
            disableNavigation={disableNavigation}
            onCompose={onCompose}
          />
        </Suspense>
      }
    >
      {children}
      <ComposeSheet isOpen={isComposeOpen} onOpenChange={setIsComposeOpen} />
    </AppLayout>
  );
}
