"use client";

import type {EmailFolder, EmailFolderId, EmailLabel} from "../data/email";

import {PencilToLine} from "@gravity-ui/icons";
import {Avatar, Button, Chip} from "@heroui/react";
import {Sidebar} from "@heroui-pro/react";

import {FOLDERS, FOLDER_UNREAD_COUNTS, LABELS} from "../data/email";

const LABEL_TONE_CLASS: Record<EmailLabel["tone"], string> = {
  accent: "bg-accent",
  danger: "bg-danger",
  default: "bg-muted",
  success: "bg-success",
  warning: "bg-warning",
};

export interface EmailSidebarProps {
  pathname: string;
  basePath: string;
  disableNavigation?: boolean;
  onCompose?: () => void;
  /** Controlled folder selection used by embedded workspaces. */
  onFolderChange?: (folderId: EmailFolderId) => void;
  selectedFolderId?: EmailFolderId;
  unreadCounts?: Readonly<Record<EmailFolderId, number>>;
}

export function EmailSidebar({
  basePath,
  disableNavigation = false,
  onCompose,
  onFolderChange,
  pathname,
  selectedFolderId,
  unreadCounts = FOLDER_UNREAD_COUNTS,
}: EmailSidebarProps) {
  const contentProps = {
    basePath,
    disableNavigation,
    onCompose,
    onFolderChange,
    pathname,
    selectedFolderId,
    unreadCounts,
  };

  return (
    <>
      <Sidebar>
        <SidebarContents {...contentProps} />
      </Sidebar>
      <Sidebar.Mobile>
        <SidebarContents {...contentProps} idPrefix="mobile-" />
      </Sidebar.Mobile>
    </>
  );
}

interface SidebarContentsProps {
  basePath: string;
  disableNavigation: boolean;
  pathname: string;
  idPrefix?: string;
  onCompose?: () => void;
  onFolderChange?: (folderId: EmailFolderId) => void;
  selectedFolderId?: EmailFolderId;
  unreadCounts: Readonly<Record<EmailFolderId, number>>;
}

function SidebarContents({
  basePath,
  disableNavigation,
  idPrefix = "",
  onCompose,
  onFolderChange,
  pathname,
  selectedFolderId,
  unreadCounts,
}: SidebarContentsProps) {
  return (
    <>
      <Sidebar.Header>
        <div className="flex items-center gap-3 px-1 py-1">
          <Avatar className="size-9">
            <Avatar.Image
              alt="You"
              src="https://heroui-assets.nyc3.cdn.digitaloceanspaces.com/avatars/blue-light.jpg"
            />
            <Avatar.Fallback>Y</Avatar.Fallback>
          </Avatar>
          <div className="flex min-w-0 flex-col" data-sidebar="label">
            <span className="text-foreground text-sm font-medium leading-tight">You</span>
            <span className="text-muted text-xs font-medium leading-tight">you@heroui.dev</span>
          </div>
        </div>
      </Sidebar.Header>
      <Sidebar.Content>
        <Sidebar.Group>
          <Sidebar.Menu aria-label="Email folders">
            {FOLDERS.map((folder) => (
              <FolderMenuItem
                key={folder.id}
                basePath={basePath}
                disableNavigation={disableNavigation}
                folder={folder}
                idPrefix={idPrefix}
                pathname={pathname}
                selectedFolderId={selectedFolderId}
                unreadCount={unreadCounts[folder.id]}
                onFolderChange={onFolderChange}
              />
            ))}
          </Sidebar.Menu>
        </Sidebar.Group>
        <Sidebar.Separator />
        <Sidebar.Group>
          <Sidebar.GroupLabel>Labels</Sidebar.GroupLabel>
          <div className="flex flex-col gap-0.5 px-2 py-1">
            {LABELS.map((label) => (
              <div
                key={label.id}
                className="flex min-h-8 items-center gap-2 px-2 text-sm"
                data-sidebar="label"
              >
                <span className={`size-2 shrink-0 rounded-full ${LABEL_TONE_CLASS[label.tone]}`} />
                <span className="text-foreground">{label.label}</span>
              </div>
            ))}
          </div>
        </Sidebar.Group>
      </Sidebar.Content>
      <Sidebar.Footer>
        <div className="px-2 pb-1">
          <Button fullWidth size="sm" onPress={onCompose}>
            <PencilToLine className="size-4" />
            New email
          </Button>
        </div>
      </Sidebar.Footer>
    </>
  );
}

interface FolderMenuItemProps {
  basePath: string;
  disableNavigation: boolean;
  folder: EmailFolder;
  idPrefix: string;
  pathname: string;
  onFolderChange?: (folderId: EmailFolderId) => void;
  selectedFolderId?: EmailFolderId;
  unreadCount: number;
}

function FolderMenuItem({
  basePath,
  disableNavigation,
  folder,
  idPrefix,
  onFolderChange,
  pathname,
  selectedFolderId,
  unreadCount,
}: FolderMenuItemProps) {
  const Icon = folder.icon;
  const fullHref = `${basePath}/${folder.id}`;
  const isCurrent = selectedFolderId
    ? selectedFolderId === folder.id
    : pathname === fullHref ||
      pathname === `${fullHref}/` ||
      pathname.startsWith(`${fullHref}/`) ||
      (folder.id === "inbox" &&
        (pathname === basePath || pathname === `${basePath}/` || pathname === "/"));
  const isControlled = Boolean(onFolderChange);

  return (
    <Sidebar.MenuItem
      href={disableNavigation || isControlled ? undefined : fullHref}
      id={`${idPrefix}${folder.id}`}
      isCurrent={isCurrent}
      textValue={folder.label}
      onPress={() => onFolderChange?.(folder.id)}
    >
      <Sidebar.MenuIcon>
        <Icon className="size-4" />
      </Sidebar.MenuIcon>
      <Sidebar.MenuLabel>{folder.label}</Sidebar.MenuLabel>
      {unreadCount > 0 ? (
        <Sidebar.MenuChip>
          <Chip size="sm" variant="soft">
            {unreadCount}
          </Chip>
        </Sidebar.MenuChip>
      ) : null}
    </Sidebar.MenuItem>
  );
}
